This is a set of helper Makefiles for doing non-recursive builds with
GNU Make.  The canonical source can be found at
https://github.com/edolstra/make-rules.  You should copy the files
into the `mk` subdirectory of your project.

TODO: write more documentation.
