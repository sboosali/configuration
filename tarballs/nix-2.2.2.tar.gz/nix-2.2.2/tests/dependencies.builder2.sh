mkdir $out
echo BAR > $out/bar
