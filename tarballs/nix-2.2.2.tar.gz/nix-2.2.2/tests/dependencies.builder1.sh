mkdir $out
echo FOO > $out/foo
