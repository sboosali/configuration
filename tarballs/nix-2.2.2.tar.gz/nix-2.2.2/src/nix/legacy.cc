#include "legacy.hh"

namespace nix {

RegisterLegacyCommand::Commands * RegisterLegacyCommand::commands = 0;

}
