#pragma once

#include "logging.hh"

namespace nix {

void startProgressBar();

void stopProgressBar();

}
